import '@fontsource/rubik/latin-300.css';
import '@fontsource/rubik/latin-400.css';
import '@fontsource/rubik/latin-500.css';
import './style.css';
import { site } from './site.config.js';

const header = document.querySelector('.header');
const menu = document.querySelector('.menu-toggle');
const nav = document.querySelector('#navigation');

function closeMenu({ restoreFocus = false } = {}) {
  menu.setAttribute('aria-expanded', 'false');
  nav.classList.remove('is-open');
  if (restoreFocus) menu.focus();
}
menu.addEventListener('click', () => {
  const expanded = menu.getAttribute('aria-expanded') !== 'true';
  menu.setAttribute('aria-expanded', String(expanded));
  nav.classList.toggle('is-open', expanded);
});
nav.addEventListener('click', event => {
  const link = event.target.closest('a');
  if (!link) return;
  closeMenu();
  if (link.hash && link.origin === location.origin) {
    const target = document.querySelector(link.hash);
    if (target) {
      target.setAttribute('tabindex', '-1');
      target.focus({ preventScroll: true });
    }
  }
});
document.addEventListener('keydown', event => {
  if (event.key === 'Escape' && menu.getAttribute('aria-expanded') === 'true') closeMenu({ restoreFocus: true });
});
document.addEventListener('click', event => {
  if (!header.contains(event.target)) closeMenu();
});
matchMedia('(min-width: 900px)').addEventListener('change', () => closeMenu());

let scrollScheduled = false;
function updateHeader() {
  header.classList.toggle('is-scrolled', window.scrollY > 48);
  scrollScheduled = false;
}
window.addEventListener('scroll', () => {
  if (!scrollScheduled) {
    scrollScheduled = true;
    requestAnimationFrame(updateHeader);
  }
}, { passive: true });
updateHeader();

const privacy = document.querySelector('#privacy-dialog');
const privacyLink = document.querySelector('[data-open-privacy]');
if (typeof privacy.showModal === 'function') {
  privacyLink.addEventListener('click', event => {
    if (event.ctrlKey || event.metaKey || event.shiftKey || event.altKey) return;
    event.preventDefault();
    privacy.showModal();
  });
  privacy.querySelector('[data-close-dialog]').addEventListener('click', () => privacy.close());
  privacy.addEventListener('click', event => {
    if (event.target !== privacy) return;
    const rect = privacy.getBoundingClientRect();
    if (event.clientX < rect.left || event.clientX > rect.right || event.clientY < rect.top || event.clientY > rect.bottom) privacy.close();
  });
}

if (/^https:\/\/(www\.)?instagram\.com\//.test(site.instagram)) {
  const link = document.querySelector('#instagram-link');
  Object.assign(link, { href: site.instagram, target: '_blank', rel: 'noopener noreferrer', hidden: false });
}
document.querySelector('#year').textContent = new Date().getFullYear();
